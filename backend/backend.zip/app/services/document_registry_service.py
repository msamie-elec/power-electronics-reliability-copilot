"""
Power Electronics Reliability Copilot
Document Registry Service

Builds a frontend-ready registry of uploaded engineering documents.

Version 0.5.2 introduces document registry integration as an intermediate
step before full document-aware engineering sessions. This service provides
stable document metadata for the Conversational Engineering Workspace while
preserving compatibility with the existing upload and evidence pipeline.
"""

import hashlib
from typing import Any

from app.services.file_service import list_uploaded_documents


class DocumentRegistryService:
    def list_documents(self) -> list[dict[str, Any]]:
        documents: list[dict[str, Any]] = []

        for document in list_uploaded_documents():
            filename = document.get("filename", "")

            if not filename:
                continue

            documents.append(
                {
                    "documentId": self._build_document_id(filename),
                    "filename": filename,
                    "sizeBytes": document.get("size_bytes"),
                    "uploadedAt": document.get("uploaded_at"),
                    "source": "upload_registry",
                    "status": "available",
                }
            )

        return documents

    def _build_document_id(self, filename: str) -> str:
        """
        Build a deterministic document ID from the filename.

        This is intentionally deterministic so the frontend can reliably
        reference uploaded documents until persistent registry metadata is
        introduced later in v0.5.2.
        """
        digest = hashlib.sha1(filename.encode("utf-8")).hexdigest()[:8].upper()
        return f"DOC-{digest}"


document_registry_service = DocumentRegistryService()